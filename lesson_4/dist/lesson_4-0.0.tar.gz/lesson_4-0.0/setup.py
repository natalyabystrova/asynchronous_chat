from setuptools import setup

setup(name='lesson_4',
      version='0.0',
      description='qwerty',
      packages=['lesson_4'],
      author_email='natalya.bystrova.93@mail.ru',
      zip_safe=False)

